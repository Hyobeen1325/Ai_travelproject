package com.example.demo.service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.example.demo.dto.ChatLogItemDto;
import com.example.demo.dto.JHRequestDto;
import com.example.demo.dto.JHRequestDto2;
import com.example.demo.dto.JHResponseDto;
import com.example.demo.dto.JHResponseDto2;

@Service
public class JHService {

    @Value("${fastapi.url:http://localhost:8000}")
    private String fastApiUrl;

    private final RestTemplate restTemplate;

    public JHService() {
        this.restTemplate = new RestTemplate();
    }

    public Map<String, Object> getJHResponse(JHRequestDto chatRequest) {
        String url = fastApiUrl + "/page04/message";
        JHResponseDto result = null;
        try {
            result = restTemplate.postForObject(url, chatRequest, JHResponseDto.class);
        } catch (Exception e) {
            System.err.println("Error calling FastAPI (getJHResponse): " + e.getMessage());
        }

        if (result == null) {
            result = new JHResponseDto();
            result.setResponse("FastAPI 응답 없음");
        } else {
            String processedResponse = processResponse(result.getResponse());
            result.setResponse(processedResponse);
        }

        Map<String, Object> responseMap = new HashMap<>();
        responseMap.put("response", result.getResponse());
        responseMap.put("chatList", buildChatLogList(result.getTitle(), result.getUpt_date()));

        return responseMap;
    }

    public Map<String, Object> getJHResponse2(JHRequestDto2 chatRequest) {
        String url = fastApiUrl + "/page3/message";
        JHResponseDto2 result = null;
        try {
            result = restTemplate.postForObject(url, chatRequest, JHResponseDto2.class);
        } catch (Exception e) {
            System.err.println("Error calling FastAPI (getJHResponse2): " + e.getMessage());
        }

        if (result == null) {
            result = new JHResponseDto2();
            result.setResponse("응답 없음");
            result.setLatitude(null);
            result.setLongitude(null);
        } else {
            String processedResponse = processResponse(result.getResponse());
            result.setResponse(processedResponse);
        }

        Map<String, Object> responseMap = new HashMap<>();
        responseMap.put("response", result.getResponse());
        responseMap.put("latitude", result.getLatitude());
        responseMap.put("longitude", result.getLongitude());
        responseMap.put("chatList", buildChatLogList(result.getTitle(), result.getUpt_date()));
        return responseMap;
    }

    private String processResponse(String response) {
        if (response == null || response.isBlank()) {
            return "FastAPI로부터 받은 유효한 응답이 없습니다.";
        }
        String trimmed = response.trim();
        String withLineBreaks = trimmed.replace("\n", "<br>");
        withLineBreaks = withLineBreaks.replaceAll("추천", "<strong>추천</strong>");
        return withLineBreaks;
    }

    private List<ChatLogItemDto> buildChatLogList(List<String> title, List<String> uptDate) {
        List<ChatLogItemDto> chatList = new ArrayList<>();
        if (uptDate != null) {
            for (int i = 0; i < uptDate.size(); i++) {
                ChatLogItemDto item = new ChatLogItemDto();
                item.setUptDate(uptDate.get(i));
                item.setTitle(title != null && i < title.size() ? title.get(i) : "");
                chatList.add(item);
            }
        } else if (title != null) {
            // uptDate가 null일 경우 title을 기준으로 순회 (혹시 모를 상황 대비)
            for (int i = 0; i < title.size(); i++) {
                ChatLogItemDto item = new ChatLogItemDto();
                item.setTitle(title.get(i));
                item.setUptDate(""); // uptDate가 없으므로 빈 문자열 설정
                chatList.add(item);
            }
        }
        return chatList;
    }
}